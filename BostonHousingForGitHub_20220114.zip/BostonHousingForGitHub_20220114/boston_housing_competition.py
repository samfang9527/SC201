"""
File: boston_housing_competition.py
Name: Sam Fang
--------------------------------
This file demonstrates how to analyze boston
housing dataset. Students will upload their 
results to kaggle.com and compete with people
in class!

You are allowed to use pandas, sklearn, or build the
model from scratch! Go data scientist!
"""

import pandas as pd
from sklearn import preprocessing, linear_model, metrics, decomposition, tree, ensemble, feature_selection
import matplotlib.pyplot as plt

"""
1. Final score: 3.70504
2. 透過相關係數 & Tree 篩選出 7 個主要維度 -> Excel CORR
3. sklearn linear model / standardize / polynomial degree 2 / PCA 18
4. All you need is gradient descent -> 找出對的方向後不斷嘗試
"""

TRAIN_FILE = 'boston_housing/train.csv'
TEST_FILE = 'boston_housing/test.csv'
OUT_FILE = 'My_Submission_PCA_7.csv'

HIGH_CORR_FEATURE = ['crim', 'nox', 'rm', 'rad', 'tax', 'ptratio', 'lstat']
# HIGH_CORR_FEATURE = ['nox', 'rm', 'dis', 'ptratio', 'lstat', 'tax']
# HIGH_CORR_FEATURE = ['dis', 'nox', 'rm', 'rad_0', 'rad_1', 'rad_2', 'rad_3', 'rad_4', 'rad_5', 'rad_6', 'rad_7', 'rad_8', 'tax', 'ptratio', 'lstat']


def pre_processing(file, mode='train'):
	data = pd.read_csv(file)
	if mode == 'train':
		data = data
		train_y = data.pop('medv')
		train_data = data[HIGH_CORR_FEATURE]
		# train_data = data
		return train_y, train_data
	elif mode == 'valid':
		data = data
		valid_y = data.pop('medv')
		valid_data = data[HIGH_CORR_FEATURE]
		return valid_y, valid_data
	else:
		id_ = data.pop('ID')
		data = data[HIGH_CORR_FEATURE]
		return id_, data


def training(y, train_data):
	# Train
	standardizer = preprocessing.StandardScaler()
	h = linear_model.LinearRegression()
	poly_feature_extractor = preprocessing.PolynomialFeatures(degree=2)
	pca = decomposition.PCA(18)
	train_data = standardizer.fit_transform(train_data)
	train_data = poly_feature_extractor.fit_transform(train_data)
	train_data = pca.fit_transform(train_data)
	print(f'PCA retention rate: {sum(pca.explained_variance_ratio_)}')
	regressor = h.fit(train_data, y)
	print('Training Acc: ', regressor.score(train_data, y))
	# return standardizer, poly_feature_extractor, regressor
	return standardizer, poly_feature_extractor, regressor, pca


def validation(standardizer, poly_feature_extractor, regressor, pca, valid_y, valid_data):
	valid_data = poly_feature_extractor.transform(valid_data)
	valid_data = standardizer.transform(valid_data)
	valid_data = pca.transform(valid_data)
	# print('validation Acc: ', regressor.score(valid_data, valid_y))
	predictions = regressor.predict(valid_data)
	score = metrics.mean_squared_error(predictions, valid_y) ** 0.5
	print(f'Validation Score: {score}')
	return predictions


def test(standardizer, poly_feature_extractor, regressor, pca, test_data):
	test_data = standardizer.transform(test_data)
	test_data = poly_feature_extractor.transform(test_data)
	test_data = pca.transform(test_data)
	predictions = regressor.predict(test_data)
	return predictions


def training_tree(train_data, train_y):
	# Tree
	# poly_feature_extractor = preprocessing.PolynomialFeatures(degree=2)
	# train_data = poly_feature_extractor.fit_transform(train_data)
	# pca = decomposition.PCA(20)
	# train_data = pca.fit_transform(train_data)
	# h = tree.DecisionTreeRegressor()
	# regressor = h.fit(train_data, train_y)
	# print(regressor.score(train_data, train_y))
	# tree.export_graphviz(regressor, out_file='tree.dot', feature_names=HIGH_CORR_FEATURE)

	# Random Forest Regressor
	standardizer = preprocessing.StandardScaler()
	poly_feature_extractor = preprocessing.PolynomialFeatures(degree=2)
	pca = decomposition.PCA(18)
	train_data = standardizer.fit_transform(train_data)
	train_data = poly_feature_extractor.fit_transform(train_data)
	train_data = pca.fit_transform(train_data)
	rfr = ensemble.RandomForestRegressor()
	rfr.fit(train_data, train_y)
	print(f'rfr score: {rfr.score(train_data, train_y)}')
	return standardizer, poly_feature_extractor, rfr, pca


def validation_tree(standardizer, poly_feature_extractor, rfr, pca, valid_y, valid_data):
	valid_data = standardizer.transform(valid_data)
	valid_data = poly_feature_extractor.transform(valid_data)
	valid_data = pca.transform(valid_data)
	predictions = rfr.predict(valid_data)
	score = metrics.mean_squared_error(predictions, valid_y) ** 0.5
	print(f'Validation Score: {score}')
	return predictions


def test_tree(standardizer, poly_feature_extractor, rfr, pca, test_data):
	test_data = standardizer.transform(test_data)
	test_data = poly_feature_extractor.transform(test_data)
	test_data = pca.transform(test_data)
	predictions = rfr.predict(test_data)
	return predictions


def feature_select(data, y):
	selector = feature_selection.RFE(estimator=linear_model.LinearRegression(), n_features_to_select=4)
	data = selector.fit(data, y)
	print(selector.ranking_)
	print(selector.support_)


def export(id_, predictions, filename):
	print('\n==========================')
	print('Writing predictions to ...')
	print(filename)
	with open(filename, 'w') as out:
		out.write('ID,medv\n')
		for i in range(predictions.size):
			out.write(f'{int(id_[i])},{float(predictions[i])}\n')
	print('\n==========================')


def data_check(data):
	d = {}
	for col in data:
		d[col] = {}
		for i in range(data[col].size):
			v = data[col][i]
			if v not in d[col]:
				d[col][v] = 1
			else:
				d[col][v] += 1
	for k, v in d.items():
		print(k, '->', v)


def main():
	"""
	Preprocessing
	"""
	# train data
	train_y, train_data = pre_processing(TRAIN_FILE, mode='train')

	# validation data
	# valid_y, valid_data = pre_processing(TRAIN_FILE, mode='valid')

	# test data
	id_, test_data = pre_processing(TEST_FILE, mode='test')

	"""
	linear model
	"""
	# training
	standardizer, poly_feature_extractor, regressor, pca = training(train_y, train_data)

	# validation
	# predictions = validation(standardizer, poly_feature_extractor, regressor, pca, valid_y, valid_data)

	# test
	predictions = test(standardizer, poly_feature_extractor, regressor, pca, test_data)

	"""
	ensemble
	"""
	# Training
	# standardizer, poly_feature_extractor, rfr, pca = training_tree(train_data, train_y)
	# training_tree(train_data, train_y)

	# Validation
	# predictions = validation_tree(standardizer, poly_feature_extractor, rfr, pca, valid_y, valid_data)

	# test
	# predictions = test(standardizer, poly_feature_extractor, rfr, pca, test_data)

	"""
	Export
	"""
	# Export predictions
	export(id_, predictions, OUT_FILE)

	"""
	Check tools
	"""
	# data_check(train_data)
	# feature_select(train_data, train_y)


if __name__ == '__main__':
	main()
